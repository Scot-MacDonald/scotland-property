import configPromise from '@payload-config'
import { getPayload } from 'payload'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'

import { getRelationshipId } from '@/lib/dashboard/workspaceHelpers'

const allowedStatuses = ['requested', 'confirmed', 'completed', 'cancelled', 'no-show'] as const

type ViewingStatus = (typeof allowedStatuses)[number]

function isViewingStatus(value: unknown): value is ViewingStatus {
  return typeof value === 'string' && allowedStatuses.includes(value as ViewingStatus)
}

function optionalString(value: unknown) {
  if (typeof value !== 'string') {
    return undefined
  }

  const trimmedValue = value.trim()

  return trimmedValue || null
}

export async function POST(request: Request) {
  try {
    const payload = await getPayload({
      config: configPromise,
    })

    const requestHeaders = await headers()

    const { user } = await payload.auth({
      headers: requestHeaders,
    })

    if (!user || user.collection !== 'users') {
      return NextResponse.json(
        {
          error: 'You must be logged in.',
        },
        {
          status: 401,
        },
      )
    }

    const body = await request.json()

    const id = typeof body.id === 'string' ? body.id : ''

    if (!id) {
      return NextResponse.json(
        {
          error: 'Viewing ID is required.',
        },
        {
          status: 400,
        },
      )
    }

    let viewing

    try {
      viewing = await payload.findByID({
        collection: 'viewings',
        id,
        depth: 0,
        overrideAccess: true,
      })
    } catch {
      return NextResponse.json(
        {
          error: 'Viewing not found.',
        },
        {
          status: 404,
        },
      )
    }

    const userAgencyId = getRelationshipId(user.agency)
    const viewingAgencyId = getRelationshipId(viewing.agency)
    const isSuperAdmin = user.role === 'super-admin'

    if (!isSuperAdmin && (!userAgencyId || viewingAgencyId !== userAgencyId)) {
      return NextResponse.json(
        {
          error: 'You do not have permission to update this viewing.',
        },
        {
          status: 403,
        },
      )
    }

    const updateData: {
      dateTime?: string
      durationMinutes?: number
      status?: ViewingStatus
      agent?: string | null
      contactName?: string
      contactEmail?: string
      contactPhone?: string | null
      internalNotes?: string | null
    } = {}

    if ('internalNotes' in body) {
      updateData.internalNotes = optionalString(body.internalNotes)
    }

    if ('contactName' in body) {
      const contactName = typeof body.contactName === 'string' ? body.contactName.trim() : ''

      if (!contactName) {
        return NextResponse.json(
          {
            error: 'Contact name is required.',
          },
          {
            status: 400,
          },
        )
      }

      updateData.contactName = contactName
    }

    if ('contactEmail' in body) {
      const contactEmail = typeof body.contactEmail === 'string' ? body.contactEmail.trim() : ''

      if (!contactEmail) {
        return NextResponse.json(
          {
            error: 'Contact email is required.',
          },
          {
            status: 400,
          },
        )
      }

      updateData.contactEmail = contactEmail
    }

    if ('contactPhone' in body) {
      updateData.contactPhone = optionalString(body.contactPhone)
    }

    if ('dateTime' in body) {
      const dateTime = new Date(body.dateTime)

      if (Number.isNaN(dateTime.getTime())) {
        return NextResponse.json(
          {
            error: 'A valid viewing date and time is required.',
          },
          {
            status: 400,
          },
        )
      }

      updateData.dateTime = dateTime.toISOString()
    }

    if ('durationMinutes' in body) {
      const durationMinutes = Number(body.durationMinutes)

      if (!Number.isFinite(durationMinutes) || durationMinutes < 15 || durationMinutes > 480) {
        return NextResponse.json(
          {
            error: 'Viewing duration is invalid.',
          },
          {
            status: 400,
          },
        )
      }

      updateData.durationMinutes = durationMinutes
    }

    if ('status' in body) {
      if (!isViewingStatus(body.status)) {
        return NextResponse.json(
          {
            error: 'Viewing status is invalid.',
          },
          {
            status: 400,
          },
        )
      }

      updateData.status = body.status
    }

    if ('agent' in body) {
      const agent = typeof body.agent === 'string' && body.agent.trim() ? body.agent.trim() : null

      if (agent) {
        let assignedAgent

        try {
          assignedAgent = await payload.findByID({
            collection: 'agents',
            id: agent,
            depth: 0,
            overrideAccess: true,
          })
        } catch {
          return NextResponse.json(
            {
              error: 'The selected agent could not be found.',
            },
            {
              status: 400,
            },
          )
        }

        const agentAgencyId = getRelationshipId(assignedAgent.agency)

        if (!isSuperAdmin && agentAgencyId !== userAgencyId) {
          return NextResponse.json(
            {
              error: 'The selected agent does not belong to your agency.',
            },
            {
              status: 403,
            },
          )
        }
      }

      updateData.agent = agent
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        {
          error: 'No viewing changes were provided.',
        },
        {
          status: 400,
        },
      )
    }

    const updatedViewing = await payload.update({
      collection: 'viewings',
      id,
      data: updateData,
      overrideAccess: true,
    })

    return NextResponse.json({
      ok: true,
      viewing: updatedViewing,
    })
  } catch (error) {
    console.error('Could not update viewing:', error)

    return NextResponse.json(
      {
        error: 'Could not update the viewing.',
      },
      {
        status: 500,
      },
    )
  }
}
