'use client'

import { useRouter } from 'next/navigation'
import { useMemo, useState, type FormEvent } from 'react'

type ViewingNotesFormProps = {
  viewingId: string
  internalNotes?: string | null
}

export function ViewingNotesForm({ viewingId, internalNotes }: ViewingNotesFormProps) {
  const router = useRouter()

  const initialValue = useMemo(() => internalNotes || '', [internalNotes])

  const [value, setValue] = useState(initialValue)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const isDirty = value !== initialValue

  function handleChange(nextValue: string) {
    setValue(nextValue)
    setError('')
    setSuccess('')
  }

  function discardChanges() {
    setValue(initialValue)
    setError('')
    setSuccess('')
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!isDirty || saving) {
      return
    }

    setSaving(true)
    setError('')
    setSuccess('')

    try {
      const response = await fetch('/api/update-viewing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: viewingId,
          internalNotes: value.trim() || null,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data?.error || 'Could not update the viewing notes.')
      }

      setSuccess('Notes updated successfully.')
      router.refresh()
    } catch (submissionError) {
      setError(
        submissionError instanceof Error
          ? submissionError.message
          : 'Could not update the viewing notes.',
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error ? (
        <div className="border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      {success ? (
        <div className="border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
          {success}
        </div>
      ) : null}

      <section className="border border-neutral-200 bg-white">
        <div className="border-b border-neutral-200 px-6 py-5">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-neutral-500">
            Internal notes
          </p>

          <h2 className="mt-2 text-xl font-semibold text-neutral-950">Appointment notes</h2>

          <p className="mt-2 text-sm leading-6 text-neutral-500">
            Record private notes for your agency team. These are not visible to the viewer.
          </p>
        </div>

        <div className="p-6">
          <label className="block">
            <span className="text-xs font-semibold uppercase tracking-[0.12em] text-neutral-500">
              Notes
            </span>

            <textarea
              value={value}
              onChange={(event) => handleChange(event.target.value)}
              rows={12}
              placeholder="Add access instructions, viewer requirements, preparation notes or follow-up details..."
              className="mt-2 w-full resize-y border border-neutral-300 bg-white px-4 py-3 text-sm leading-7 text-neutral-950 outline-none transition placeholder:text-neutral-400 focus:border-neutral-950 disabled:cursor-not-allowed disabled:bg-neutral-100"
            />
          </label>
        </div>
      </section>

      <div className="flex flex-col gap-3 border-t border-neutral-200 pt-6 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral-500">
          {isDirty ? 'You have unsaved changes.' : 'All changes are saved.'}
        </p>

        <div className="flex gap-3">
          <button
            type="button"
            onClick={discardChanges}
            disabled={!isDirty || saving}
            className="inline-flex h-10 items-center justify-center border border-neutral-300 bg-white px-4 text-sm font-semibold text-neutral-800 transition hover:border-neutral-400 hover:bg-neutral-50 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Discard
          </button>

          <button
            type="submit"
            disabled={!isDirty || saving}
            className="inline-flex h-10 items-center justify-center bg-neutral-950 px-4 text-sm font-semibold text-white transition hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {saving ? 'Saving…' : 'Save notes'}
          </button>
        </div>
      </div>
    </form>
  )
}
