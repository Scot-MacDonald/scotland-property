'use client'

import { useRouter } from 'next/navigation'
import { useMemo, useState, type FormEvent } from 'react'

type AgentOption = {
  id: string
  label: string
}

type ViewingOverviewFormProps = {
  viewing: {
    id: string
    dateTime: string
    durationMinutes?: number | null
    status?: string | null
    agentId?: string | null
    contactName: string
    contactEmail: string
    contactPhone?: string | null
  }
  agents: AgentOption[]
}

const viewingStatuses = [
  {
    value: 'requested',
    label: 'Requested',
  },
  {
    value: 'confirmed',
    label: 'Confirmed',
  },
  {
    value: 'completed',
    label: 'Completed',
  },
  {
    value: 'cancelled',
    label: 'Cancelled',
  },
  {
    value: 'no-show',
    label: 'No show',
  },
]

const durationOptions = [15, 30, 45, 60, 75, 90, 120]

function formatDateTimeLocal(value: string) {
  const date = new Date(value)

  if (Number.isNaN(date.getTime())) {
    return ''
  }

  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')

  return `${year}-${month}-${day}T${hours}:${minutes}`
}

export function ViewingOverviewForm({ viewing, agents }: ViewingOverviewFormProps) {
  const router = useRouter()

  const initialValues = useMemo(
    () => ({
      dateTime: formatDateTimeLocal(viewing.dateTime),
      durationMinutes: String(viewing.durationMinutes || 60),
      status: viewing.status || 'requested',
      agent: viewing.agentId || '',
      contactName: viewing.contactName || '',
      contactEmail: viewing.contactEmail || '',
      contactPhone: viewing.contactPhone || '',
    }),
    [viewing],
  )

  const [values, setValues] = useState(initialValues)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const isDirty = useMemo(
    () =>
      values.dateTime !== initialValues.dateTime ||
      values.durationMinutes !== initialValues.durationMinutes ||
      values.status !== initialValues.status ||
      values.agent !== initialValues.agent ||
      values.contactName !== initialValues.contactName ||
      values.contactEmail !== initialValues.contactEmail ||
      values.contactPhone !== initialValues.contactPhone,
    [initialValues, values],
  )

  function updateField(field: keyof typeof values, value: string) {
    setValues((current) => ({
      ...current,
      [field]: value,
    }))

    setError('')
    setSuccess('')
  }

  function discardChanges() {
    setValues(initialValues)
    setError('')
    setSuccess('')
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!isDirty || saving) {
      return
    }

    setSaving(true)
    setError('')
    setSuccess('')

    try {
      const response = await fetch('/api/update-viewing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: viewing.id,
          dateTime: values.dateTime,
          durationMinutes: Number(values.durationMinutes),
          status: values.status,
          agent: values.agent || null,
          contactName: values.contactName.trim(),
          contactEmail: values.contactEmail.trim(),
          contactPhone: values.contactPhone.trim() || null,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data?.error || 'Could not update the viewing.')
      }

      setSuccess('Viewing updated successfully.')
      router.refresh()
    } catch (submissionError) {
      setError(
        submissionError instanceof Error
          ? submissionError.message
          : 'Could not update the viewing.',
      )
    } finally {
      setSaving(false)
    }
  }

  const inputClasses =
    'mt-2 h-11 w-full border border-neutral-300 bg-white px-3 text-sm text-neutral-950 outline-none transition focus:border-neutral-950 disabled:cursor-not-allowed disabled:bg-neutral-100'

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error ? (
        <div className="border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      {success ? (
        <div className="border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
          {success}
        </div>
      ) : null}

      <section className="border border-neutral-200 bg-white">
        <div className="border-b border-neutral-200 px-6 py-5">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-neutral-500">
            Appointment
          </p>

          <h2 className="mt-2 text-xl font-semibold text-neutral-950">Viewing overview</h2>

          <p className="mt-2 text-sm leading-6 text-neutral-500">
            Manage the appointment time, status, duration and assigned agent.
          </p>
        </div>

        <div className="grid gap-6 p-6 md:grid-cols-2">
          <Field label="Date and time" required>
            <input
              type="datetime-local"
              value={values.dateTime}
              onChange={(event) => updateField('dateTime', event.target.value)}
              className={inputClasses}
              required
            />
          </Field>

          <Field label="Status" required>
            <select
              value={values.status}
              onChange={(event) => updateField('status', event.target.value)}
              className={inputClasses}
              required
            >
              {viewingStatuses.map((status) => (
                <option key={status.value} value={status.value}>
                  {status.label}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Duration" required>
            <select
              value={values.durationMinutes}
              onChange={(event) => updateField('durationMinutes', event.target.value)}
              className={inputClasses}
              required
            >
              {durationOptions.map((duration) => (
                <option key={duration} value={duration}>
                  {duration} minutes
                </option>
              ))}
            </select>
          </Field>

          <Field label="Assigned agent">
            <select
              value={values.agent}
              onChange={(event) => updateField('agent', event.target.value)}
              className={inputClasses}
            >
              <option value="">No assigned agent</option>

              {agents.map((agent) => (
                <option key={agent.id} value={agent.id}>
                  {agent.label}
                </option>
              ))}
            </select>
          </Field>
        </div>
      </section>

      <section className="border border-neutral-200 bg-white">
        <div className="border-b border-neutral-200 px-6 py-5">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-neutral-500">
            Contact
          </p>

          <h2 className="mt-2 text-xl font-semibold text-neutral-950">Viewer details</h2>

          <p className="mt-2 text-sm leading-6 text-neutral-500">
            Update the person attending the appointment.
          </p>
        </div>

        <div className="grid gap-6 p-6 md:grid-cols-2">
          <Field label="Name" required>
            <input
              type="text"
              value={values.contactName}
              onChange={(event) => updateField('contactName', event.target.value)}
              className={inputClasses}
              required
            />
          </Field>

          <Field label="Email" required>
            <input
              type="email"
              value={values.contactEmail}
              onChange={(event) => updateField('contactEmail', event.target.value)}
              className={inputClasses}
              required
            />
          </Field>

          <Field label="Phone">
            <input
              type="tel"
              value={values.contactPhone}
              onChange={(event) => updateField('contactPhone', event.target.value)}
              className={inputClasses}
            />
          </Field>
        </div>
      </section>

      <div className="flex flex-col gap-3 border-t border-neutral-200 pt-6 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral-500">
          {isDirty ? 'You have unsaved changes.' : 'All changes are saved.'}
        </p>

        <div className="flex gap-3">
          <button
            type="button"
            onClick={discardChanges}
            disabled={!isDirty || saving}
            className="inline-flex h-10 items-center justify-center border border-neutral-300 bg-white px-4 text-sm font-semibold text-neutral-800 transition hover:border-neutral-400 hover:bg-neutral-50 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Discard
          </button>

          <button
            type="submit"
            disabled={!isDirty || saving}
            className="inline-flex h-10 items-center justify-center bg-neutral-950 px-4 text-sm font-semibold text-white transition hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {saving ? 'Saving…' : 'Save changes'}
          </button>
        </div>
      </div>
    </form>
  )
}

function Field({
  label,
  required = false,
  children,
}: {
  label: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-[0.12em] text-neutral-500">
        {label}
        {required ? <span className="ml-1 text-red-600">*</span> : null}
      </span>

      {children}
    </label>
  )
}
